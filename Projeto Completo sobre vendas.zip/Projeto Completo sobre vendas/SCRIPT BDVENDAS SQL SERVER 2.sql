
create database bdvendas7;

use bdvendas7;

CREATE TABLE cliente (
  id int NOT NULL primary key identity,
  nome varchar(100) DEFAULT NULL,
    email varchar(50) DEFAULT NULL,
  telefone varchar(45) DEFAULT NULL,
  data int
)

select * from cliente;

CREATE TABLE fornecedor (
  id int NOT NULL primary key identity,
  nome varchar(100) DEFAULT NULL,
  cnpj varchar(50) DEFAULT NULL,
  endereco varchar(100) DEFAULT NULL,
  bairro varchar(100) DEFAULT NULL,
  cidade varchar(100) DEFAULT NULL,
  numero int DEFAULT NULL,
  telefone varchar(20) DEFAULT NULL,
  email varchar(50) DEFAULT NULL, 
)

CREATE TABLE produto (
	  id int NOT NULL identity primary key,
	  descricao varchar(45) DEFAULT NULL,
	  preco decimal, 
	  qtd int  NULL,
	  for_id int NOT NULL
  )

  CREATE TABLE vendas (
	  id int NOT NULL primary key identity,
	  data_venda date,
	  total_venda decimal,
	  cliente_id int NOT NULL
  );

  CREATE TABLE itemvenda(
	  id int NOT NULL identity primary key,
	  produto_id int NOT NULL,
	  venda_id int NOT NULL,
	  qtd int DEFAULT NULL,
	  sub_total decimal NULL
  );



  alter table itemvenda add constraint fk_itemvenda_pk_itemvenda foreign key (produto_id) references produto (id);
    alter table itemvenda add constraint fk_itemvenda_pk_vendas foreign key (venda_id) references vendas (id);
	  alter table vendas add constraint fk_vendas_pk_cliente foreign key (cliente_id) references cliente (id);
	    alter table produto add constraint fk_produto_pk_fornecedor foreign key (for_id) references fornecedor (id)


		select *from cliente;

 drop database bdvendas2;