﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoVendas.br.com.projeto.dao
{
   

         public class ConnectionFactory
    {
        //Criar o metodo que Conecta no Banco
        public SqlConnection getConnection()
        {
            try
            {
                string conexao = ConfigurationManager.ConnectionStrings["bdvendas2"].ConnectionString;
                                                             
                return new SqlConnection(conexao);  
            }
            catch (Exception erro)
            {
                MessageBox.Show("Erro ao conectar: " + erro);
                return null;
            }            
        }

    }
}
