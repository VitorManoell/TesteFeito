﻿using ProjetoVendas.br.com.projeto.model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.br.com.projeto.dao
{
    class VendasDAO
    {
        private SqlConnection conexao;

        public VendasDAO()
        {
            conexao = new ConnectionFactory().getConnection();
        }

        public void cadastrar(Vendas obj)
        {
            string sql = @"insert into vendas (data_venda, total_venda, cliente_id, data_venda)
                          values (@data, @total, @cliente, @data)";

            SqlCommand comando = new SqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@data", obj.Data_Venda);
            comando.Parameters.AddWithValue("@total", obj.Total_Venda);
            comando.Parameters.AddWithValue("@data", obj.Data_Venda);
            comando.Parameters.AddWithValue("@cliente", obj.Cliente_id);
           

            conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public void alterar(Vendas obj)
        {
            string sql = @"update vendas set data_venda = @data, total_venda = @total, cliente_id = @cliente where id = @id";

            SqlCommand comando = new SqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@data", obj.Data_Venda);
            comando.Parameters.AddWithValue("@total", obj.Total_Venda);
            comando.Parameters.AddWithValue("@cliente", obj.Cliente_id);
            comando.Parameters.AddWithValue("@id", obj.id);

            conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public void excluir(Vendas obj)
        {
            string sql = @"delete from vendas where id = @id";

            SqlCommand comando = new SqlCommand(sql, conexao);

            comando.Parameters.AddWithValue("@id", obj.id);

            conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public DataTable ListarTodosVendas()
        {
            string sql = @"select *from vendas";

            SqlCommand executacmd = new SqlCommand(sql, conexao);

            conexao.Open();
            executacmd.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(executacmd);

            DataTable tabelaV = new DataTable();
            da.Fill(tabelaV);

            conexao.Close();

            return tabelaV;
        }

        public DataTable buscarNome(Vendas obj)
        {
            string sql = @"select * from vendas where cliente_id = @cliente";

            SqlCommand executacmd = new SqlCommand(sql, conexao);
            executacmd.Parameters.AddWithValue(@"cliente", obj.Cliente_id);

            conexao.Open();
            executacmd.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(executacmd);

            DataTable tabelaV = new DataTable();
            da.Fill(tabelaV);

            conexao.Close();

            return tabelaV;
        }
        public DataTable Atualizar(string nome)
        {

            //1 passo - comando sql
            string sql = @"select * from vendas";
            //2 passo - organizar o sql
            SqlCommand executacmdsql = new SqlCommand(sql, conexao);
            executacmdsql.Parameters.AddWithValue("@nome", nome);
            //3 passo - abrir a conexao e executar o comando
            conexao.Open();
            executacmdsql.ExecuteNonQuery();
            //4 passo - criar o MySQLDataAdapter
            SqlDataAdapter da = new SqlDataAdapter(executacmdsql);
            //5 passo - criar o DataTable
            DataTable tabelaV = new DataTable();
            da.Fill(tabelaV);
            //fechar
            conexao.Close();
            //Retornar o DataTable com os dados
            return tabelaV;
        }

    }
}
