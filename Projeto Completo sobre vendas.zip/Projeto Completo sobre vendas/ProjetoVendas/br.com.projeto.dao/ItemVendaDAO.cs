﻿using ProjetoVendas.br.com.projeto.model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.br.com.projeto.dao
{
    class ItemVendaDAO
    {
        private SqlConnection conexao;

        public ItemVendaDAO()
        {
            conexao = new ConnectionFactory().getConnection();
        }

        public void cadastrar(ItemVenda obj)
        {
            string sql = @"insert into itemvenda (produto_id, venda_id, qtd, sub_total)
                          values (@produto, @venda, @qtd, @sub)";

            SqlCommand comando = new SqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@produto", obj.Produto_id);
            comando.Parameters.AddWithValue("@venda", obj.Venda_id);
            comando.Parameters.AddWithValue("@qtd", obj.Quantidade);
            comando.Parameters.AddWithValue("@sub", obj.Sub_Total);



           conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public void alterar(ItemVenda obj)
        {
            string sql = @"update vendas set produto_id = @produto, venda_id = @venda, qtd = @qtd, sub_total = @sub where id = @id";


            SqlCommand comando = new SqlCommand(sql, conexao);
            
            comando.Parameters.AddWithValue("@produto", obj.Produto_id);
            comando.Parameters.AddWithValue("@venda", obj.Venda_id);
            comando.Parameters.AddWithValue("@qtd", obj.Quantidade);
            comando.Parameters.AddWithValue("@sub", obj.Sub_Total);
            comando.Parameters.AddWithValue("@id", obj.id);
            conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public void excluir(ItemVenda obj)
        {
            string sql = @"delete from itemvenda where id = @id";

            SqlCommand comando = new SqlCommand(sql, conexao);

            comando.Parameters.AddWithValue("@id", obj.id);

            conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public DataTable ListarTodosItemVendas()
        {
            string sql = @"select *from itemvenda";

            SqlCommand executacmd = new SqlCommand(sql, conexao);

            conexao.Open();
            executacmd.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(executacmd);

            DataTable tabelaI = new DataTable();
            da.Fill(tabelaI);

            conexao.Close();

            return tabelaI;
        }

        public DataTable buscarNome(ItemVenda obj)
        {
            string sql = @"select * from itemvenda where produto_id = @produto";

            SqlCommand executacmd = new SqlCommand(sql, conexao);
            executacmd.Parameters.AddWithValue(@"produto", obj.Produto_id);

            conexao.Open();
            executacmd.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(executacmd);

            DataTable tabelaI = new DataTable();
            da.Fill(tabelaI);

            conexao.Close();

            return tabelaI;
        }

        public DataTable Atualizar(string nome)
        {

            //1 passo - comando sql
            string sql = @"select * from itemvenda";
            //2 passo - organizar o sql
            SqlCommand executacmdsql = new SqlCommand(sql, conexao);
            executacmdsql.Parameters.AddWithValue("@nome", nome);
            //3 passo - abrir a conexao e executar o comando
            conexao.Open();
            executacmdsql.ExecuteNonQuery();
            //4 passo - criar o MySQLDataAdapter
            SqlDataAdapter da = new SqlDataAdapter(executacmdsql);
            //5 passo - criar o DataTable
            DataTable tabelaI = new DataTable();
            da.Fill(tabelaI);
            //fechar
            conexao.Close();
            //Retornar o DataTable com os dados
            return tabelaI;
        }

    }
}
