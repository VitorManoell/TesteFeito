﻿using ProjetoVendas.br.com.projeto.model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.br.com.projeto.dao
{
    class FornecedorDAO
    {
        private SqlConnection conexao;

        public FornecedorDAO()
        {
            conexao = new ConnectionFactory().getConnection();
        }

        public void cadastrar(Fornecedor obj)
        {
            string sql = @"insert into fornecedor (nome, cnpj, endereco, bairro, cidade, numero, telefone, email)
                          values (@nome, @cnpj, @endereco, @bairro, @cidade, @numero, @telefone, @email)";

            SqlCommand comando = new SqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@nome", obj.Nome);
            comando.Parameters.AddWithValue("@cnpj", obj.CNPJ);
            comando.Parameters.AddWithValue("@endereco", obj.Endereco);
            comando.Parameters.AddWithValue("@bairro", obj.Bairro);
            comando.Parameters.AddWithValue("@cidade", obj.Cidade);
            comando.Parameters.AddWithValue("@numero", obj.Numero);
            comando.Parameters.AddWithValue("@telefone", obj.Telefone);
            comando.Parameters.AddWithValue("@email", obj.Email);

            conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public void alterar(Fornecedor obj)
        {
            string sql = @"update fornecedor set nome = @nome, cnpj = @cnpj, endereco = @endereco, bairro = @bairro, cidade = @cidade, numero = @numero, telefone = @telefone, email= @email where id = @id";

            SqlCommand comando = new SqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@nome", obj.Nome);
            comando.Parameters.AddWithValue("@cnpj", obj.CNPJ);
            comando.Parameters.AddWithValue("@endereco", obj.Endereco);
            comando.Parameters.AddWithValue("@bairro", obj.Bairro);
            comando.Parameters.AddWithValue("@cidade", obj.Cidade);
            comando.Parameters.AddWithValue("@numero", obj.Numero);
            comando.Parameters.AddWithValue("@telefone", obj.Telefone);
            comando.Parameters.AddWithValue("@email", obj.Email);
            comando.Parameters.AddWithValue("@id", obj.id);

            conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public void excluir(Fornecedor obj)
        {
            string sql = @"delete from fornecedor where id = @id";

            SqlCommand comando = new SqlCommand(sql, conexao);

            comando.Parameters.AddWithValue("@id", obj.id);

            conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public DataTable ListarTodosFornecedores()
        {
            string sql = @"select *from fornecedor";

            SqlCommand executacmd = new SqlCommand(sql, conexao);

            conexao.Open();
            executacmd.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(executacmd);

            DataTable tabelaF = new DataTable();
            da.Fill(tabelaF);

            conexao.Close();

            return tabelaF;
        }

        public DataTable BuscarPorNome(Fornecedor obj)
        {
            string sql = @"select * from fornecedor where nome = @nome";

            SqlCommand executacmd = new SqlCommand(sql, conexao);
            executacmd.Parameters.AddWithValue(@"nome", obj.Nome);

            conexao.Open();
            executacmd.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(executacmd);

            DataTable tabelaF = new DataTable();
            da.Fill(tabelaF);

            conexao.Close();

            return tabelaF;
        }

        public DataTable Atualizar(string nome)
        {

            //1 passo - comando sql
            string sql = @"select * from Fornecedor";
            //2 passo - organizar o sql
            SqlCommand executacmdsql = new SqlCommand(sql, conexao);
            executacmdsql.Parameters.AddWithValue("@nome", nome);
            //3 passo - abrir a conexao e executar o comando
            conexao.Open();
            executacmdsql.ExecuteNonQuery();
            //4 passo - criar o MySQLDataAdapter
            SqlDataAdapter da = new SqlDataAdapter(executacmdsql);
            //5 passo - criar o DataTable
            DataTable tabelaF = new DataTable();
            da.Fill(tabelaF);
            //fechar
            conexao.Close();
            //Retornar o DataTable com os dados
            return tabelaF;
        }
    }
}
