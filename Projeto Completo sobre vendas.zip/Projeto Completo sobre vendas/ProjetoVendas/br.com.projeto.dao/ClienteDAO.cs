﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using ProjetoVendas.br.com.projeto.model;
using System.Data;

namespace ProjetoVendas.br.com.projeto.dao
{
    class ClienteDAO
    {
        private SqlConnection conexao;

        public ClienteDAO()
        {
            conexao = new ConnectionFactory().getConnection();
        }

        public void cadastrar(Cliente obj)
        {
            string sql = @"insert into cliente ( nome, email, telefone)
                          values ( @nome, @email, @telefone )";

            SqlCommand comando = new SqlCommand(sql, conexao);
    
            comando.Parameters.AddWithValue("@nome", obj.Nome);
            comando.Parameters.AddWithValue("@email", obj.Email);
            comando.Parameters.AddWithValue("@telefone", obj.Telefone);
          
         

            conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public void alterar(Cliente obj)
        {
            string sql = @"update cliente set nome = @nome, email = @email,  telefone = @telefone where id = @id";

            SqlCommand comando = new SqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@id", obj.Id);
            comando.Parameters.AddWithValue("@nome", obj.Nome);
            comando.Parameters.AddWithValue("@email", obj.Email);
            comando.Parameters.AddWithValue("@telefone", obj.Telefone);
   
        

            conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public void excluir(Cliente obj)
        {
            string sql = @"delete from cliente where id = @id";

            SqlCommand comando = new SqlCommand(sql, conexao);

            comando.Parameters.AddWithValue("@id", obj.Id);

            conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public DataTable ListarTodosClientes()
        {
            string sql = @"select *from cliente";

            SqlCommand executacmd = new SqlCommand(sql, conexao);

            conexao.Open();
            executacmd.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(executacmd);

            DataTable tabelaCliente = new DataTable();
            da.Fill(tabelaCliente);

            conexao.Close();

            return tabelaCliente;
        }

        public DataTable buscarNome(Cliente obj)
        {
            string sql = @"select * from cliente where nome like '%'+@nome+'%'";

            SqlCommand executacmd = new SqlCommand(sql, conexao);
            executacmd.Parameters.AddWithValue(@"nome", obj.Nome);

            conexao.Open();
            executacmd.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(executacmd);

            DataTable tabelaCliente = new DataTable();
            da.Fill(tabelaCliente);

            conexao.Close();

            return tabelaCliente;
        }
        public DataTable Atualizar(string nome)
        {
         
                //1 passo - comando sql
                string sql = @"select * from cliente";
                //2 passo - organizar o sql
                SqlCommand executacmdsql = new SqlCommand(sql, conexao);
                executacmdsql.Parameters.AddWithValue("@nome", nome);
                //3 passo - abrir a conexao e executar o comando
                conexao.Open();
                executacmdsql.ExecuteNonQuery();
                //4 passo - criar o MySQLDataAdapter
                SqlDataAdapter da = new SqlDataAdapter(executacmdsql);
                //5 passo - criar o DataTable
                DataTable tabelaCliente = new DataTable();
                da.Fill(tabelaCliente);
                //fechar
                conexao.Close();
                //Retornar o DataTable com os dados
                return tabelaCliente;
            }
        }

    }

