﻿using ProjetoVendas.br.com.projeto.model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.br.com.projeto.dao
{
    class ProdutoDAO
    {
        private SqlConnection conexao;

        public ProdutoDAO()
        {
            conexao = new ConnectionFactory().getConnection();
        }

        public void cadastrar(Produto obj)
        {
            string sql = @"insert into produto (descricao, preco, qtd, for_id)
                          values (@descricao, @preco, @qtd, @for_id)";

            SqlCommand comando = new SqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@descricao", obj.Descricao);
            comando.Parameters.AddWithValue("@preco", obj.Preco);
            comando.Parameters.AddWithValue("@qtd", obj.Quantidade);
            comando.Parameters.AddWithValue("@for_id", obj.for_id);


            conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public void alterar(Produto obj)
        {
            string sql = @"update produto set descricao = @descricao, preco = @preco, qtd = @qtd, for_id = @for_id where id = @id";

            SqlCommand comando = new SqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@descricao", obj.Descricao);
            comando.Parameters.AddWithValue("@preco", obj.Preco);
            comando.Parameters.AddWithValue("@qtd", obj.Quantidade);
            comando.Parameters.AddWithValue("@for_id", obj.for_id);
            comando.Parameters.AddWithValue("@id", obj.id);

            conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public void excluir(Produto obj)
        {
            string sql = @"delete from produto where id = @id";

            SqlCommand comando = new SqlCommand(sql, conexao);

            comando.Parameters.AddWithValue("@id", obj.id);

            conexao.Open();

            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public DataTable ListarTodosProdutos()
        {
            string sql = @"select *from produto";

            SqlCommand executacmd = new SqlCommand(sql, conexao);

            conexao.Open();
            executacmd.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(executacmd);

            DataTable tabelaP = new DataTable();
            da.Fill(tabelaP);

            conexao.Close();

            return tabelaP;
        }

        public DataTable buscarNome(Produto obj)
        {
            string sql = @"select * from produto where descricao = @desc";

            SqlCommand executacmd = new SqlCommand(sql, conexao);
            executacmd.Parameters.AddWithValue(@"desc", obj.Descricao);

            conexao.Open();
            executacmd.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(executacmd);

            DataTable tabelaP = new DataTable();
            da.Fill(tabelaP);

            conexao.Close();

            return tabelaP;
        }

        public DataTable Atualizar(string nome)
        {

            //1 passo - comando sql
            string sql = @"select * from produto";
            //2 passo - organizar o sql
            SqlCommand executacmdsql = new SqlCommand(sql, conexao);
            executacmdsql.Parameters.AddWithValue("@nome", nome);
            //3 passo - abrir a conexao e executar o comando
            conexao.Open();
            executacmdsql.ExecuteNonQuery();
            //4 passo - criar o MySQLDataAdapter
            SqlDataAdapter da = new SqlDataAdapter(executacmdsql);
            //5 passo - criar o DataTable
            DataTable tabelaP = new DataTable();
            da.Fill(tabelaP);
            //fechar
            conexao.Close();
            //Retornar o DataTable com os dados
            return tabelaP;
        }

    }
}
