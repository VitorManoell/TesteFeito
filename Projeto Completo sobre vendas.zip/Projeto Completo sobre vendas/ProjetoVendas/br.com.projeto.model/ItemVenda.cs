﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.br.com.projeto.model
{
    class ItemVenda
    {
        public int id { get; set; }
        public int Produto_id { get; set; }
        public int Venda_id { get; set; }
        public int Quantidade { get; set; }
        public double Sub_Total { get; set; }


    }
}
