﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.br.com.projeto.model
{
    class Vendas
    {  public int id { get; set; }
        public DateTime Data_Venda { get; set; }
        public int Total_Venda { get; set; }
        public int Cliente_id { get; set; }

    }
}
