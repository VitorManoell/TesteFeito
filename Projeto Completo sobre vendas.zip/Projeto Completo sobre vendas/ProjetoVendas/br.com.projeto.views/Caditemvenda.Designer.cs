﻿namespace ProjetoVendas.br.com.projeto.views
{
    partial class Caditemvenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabelaI = new System.Windows.Forms.DataGridView();
            this.btnexcluir = new System.Windows.Forms.Button();
            this.btnalterar = new System.Windows.Forms.Button();
            this.btncad = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtqtd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtsub = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtcod = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbproduto = new System.Windows.Forms.ComboBox();
            this.cbvenda = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnatualizar = new System.Windows.Forms.Button();
            this.btnbuscar = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtbuscar = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.tabelaI)).BeginInit();
            this.SuspendLayout();
            // 
            // tabelaI
            // 
            this.tabelaI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tabelaI.Location = new System.Drawing.Point(371, 80);
            this.tabelaI.Name = "tabelaI";
            this.tabelaI.Size = new System.Drawing.Size(390, 334);
            this.tabelaI.TabIndex = 42;
            this.tabelaI.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tabelaI_CellContentClick);
            // 
            // btnexcluir
            // 
            this.btnexcluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnexcluir.ForeColor = System.Drawing.Color.Red;
            this.btnexcluir.Location = new System.Drawing.Point(234, 156);
            this.btnexcluir.Name = "btnexcluir";
            this.btnexcluir.Size = new System.Drawing.Size(92, 35);
            this.btnexcluir.TabIndex = 41;
            this.btnexcluir.Text = "Excluir";
            this.btnexcluir.UseVisualStyleBackColor = true;
            this.btnexcluir.Click += new System.EventHandler(this.btnexcluir_Click);
            // 
            // btnalterar
            // 
            this.btnalterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnalterar.Location = new System.Drawing.Point(234, 210);
            this.btnalterar.Name = "btnalterar";
            this.btnalterar.Size = new System.Drawing.Size(92, 35);
            this.btnalterar.TabIndex = 40;
            this.btnalterar.Text = "Alterar";
            this.btnalterar.UseVisualStyleBackColor = true;
            this.btnalterar.Click += new System.EventHandler(this.btnalterar_Click);
            // 
            // btncad
            // 
            this.btncad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btncad.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btncad.Location = new System.Drawing.Point(234, 115);
            this.btncad.Name = "btncad";
            this.btncad.Size = new System.Drawing.Size(92, 35);
            this.btncad.TabIndex = 39;
            this.btncad.Text = "Cadastrar";
            this.btncad.UseVisualStyleBackColor = true;
            this.btncad.Click += new System.EventHandler(this.btncad_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(40, 254);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 20);
            this.label5.TabIndex = 37;
            this.label5.Text = "Quantidade:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtqtd
            // 
            this.txtqtd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtqtd.Location = new System.Drawing.Point(44, 290);
            this.txtqtd.Name = "txtqtd";
            this.txtqtd.Size = new System.Drawing.Size(159, 26);
            this.txtqtd.TabIndex = 36;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(40, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 20);
            this.label4.TabIndex = 35;
            this.label4.Text = "Venda";
            // 
            // txtsub
            // 
            this.txtsub.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtsub.Location = new System.Drawing.Point(44, 357);
            this.txtsub.Name = "txtsub";
            this.txtsub.Size = new System.Drawing.Size(159, 26);
            this.txtsub.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(40, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 20);
            this.label3.TabIndex = 33;
            this.label3.Text = "Produto";
            // 
            // txtcod
            // 
            this.txtcod.Enabled = false;
            this.txtcod.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtcod.Location = new System.Drawing.Point(44, 115);
            this.txtcod.Name = "txtcod";
            this.txtcod.Size = new System.Drawing.Size(55, 26);
            this.txtcod.TabIndex = 32;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(40, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 20);
            this.label2.TabIndex = 31;
            this.label2.Text = "Código:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.label1.Location = new System.Drawing.Point(207, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(276, 25);
            this.label1.TabIndex = 30;
            this.label1.Text = "CADASTRO ITEM VENDAS";
            // 
            // cbproduto
            // 
            this.cbproduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbproduto.FormattingEnabled = true;
            this.cbproduto.Location = new System.Drawing.Point(44, 167);
            this.cbproduto.Name = "cbproduto";
            this.cbproduto.Size = new System.Drawing.Size(159, 28);
            this.cbproduto.TabIndex = 43;
            // 
            // cbvenda
            // 
            this.cbvenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbvenda.FormattingEnabled = true;
            this.cbvenda.Location = new System.Drawing.Point(44, 223);
            this.cbvenda.Name = "cbvenda";
            this.cbvenda.Size = new System.Drawing.Size(159, 28);
            this.cbvenda.TabIndex = 44;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.Location = new System.Drawing.Point(40, 319);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 20);
            this.label6.TabIndex = 45;
            this.label6.Text = "Sub_total:";
            // 
            // btnatualizar
            // 
            this.btnatualizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnatualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnatualizar.Location = new System.Drawing.Point(487, 420);
            this.btnatualizar.Name = "btnatualizar";
            this.btnatualizar.Size = new System.Drawing.Size(133, 19);
            this.btnatualizar.TabIndex = 52;
            this.btnatualizar.Text = "ATUALIZAR";
            this.btnatualizar.UseVisualStyleBackColor = true;
            this.btnatualizar.Click += new System.EventHandler(this.btnatualizar_Click);
            // 
            // btnbuscar
            // 
            this.btnbuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnbuscar.ForeColor = System.Drawing.Color.Red;
            this.btnbuscar.Location = new System.Drawing.Point(668, 48);
            this.btnbuscar.Name = "btnbuscar";
            this.btnbuscar.Size = new System.Drawing.Size(67, 27);
            this.btnbuscar.TabIndex = 51;
            this.btnbuscar.Text = "Buscar";
            this.btnbuscar.UseVisualStyleBackColor = true;
            this.btnbuscar.Click += new System.EventHandler(this.btnbuscar_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label11.Location = new System.Drawing.Point(428, 51);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 20);
            this.label11.TabIndex = 50;
            this.label11.Text = "Buscar:";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // txtbuscar
            // 
            this.txtbuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtbuscar.Location = new System.Drawing.Point(503, 48);
            this.txtbuscar.Name = "txtbuscar";
            this.txtbuscar.Size = new System.Drawing.Size(159, 26);
            this.txtbuscar.TabIndex = 49;
            this.txtbuscar.TextChanged += new System.EventHandler(this.txtbuscar_TextChanged);
            // 
            // Caditemvenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnatualizar);
            this.Controls.Add(this.btnbuscar);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtbuscar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbvenda);
            this.Controls.Add(this.cbproduto);
            this.Controls.Add(this.tabelaI);
            this.Controls.Add(this.btnexcluir);
            this.Controls.Add(this.btnalterar);
            this.Controls.Add(this.btncad);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtqtd);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtsub);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtcod);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Caditemvenda";
            this.Text = "Caditemvenda";
            this.Load += new System.EventHandler(this.Caditemvenda_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tabelaI)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView tabelaI;
        private System.Windows.Forms.Button btnexcluir;
        private System.Windows.Forms.Button btnalterar;
        private System.Windows.Forms.Button btncad;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtqtd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtsub;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtcod;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbproduto;
        private System.Windows.Forms.ComboBox cbvenda;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnatualizar;
        private System.Windows.Forms.Button btnbuscar;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtbuscar;
    }
}