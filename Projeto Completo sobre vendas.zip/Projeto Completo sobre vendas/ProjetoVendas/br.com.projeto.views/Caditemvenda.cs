﻿using ProjetoVendas.br.com.projeto.dao;
using ProjetoVendas.br.com.projeto.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoVendas.br.com.projeto.views
{
    public partial class Caditemvenda : Form
    {
        public Caditemvenda()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btncad_Click(object sender, EventArgs e)
        {
            try
            {
                ItemVenda obj = new ItemVenda();

                obj.Produto_id = int.Parse(cbproduto.SelectedValue.ToString());
                obj.Venda_id = int.Parse(cbvenda.Text);
                obj.Quantidade = int.Parse(txtqtd.Text);
                obj.Sub_Total = int.Parse(txtsub.Text);

                ItemVendaDAO dao = new ItemVendaDAO();
                dao.cadastrar(obj);
                MessageBox.Show("Cadastrado com Sucesso!!");
            }
            catch (Exception erro)
            {
                MessageBox.Show("ERRO : " + erro);
            }
        }

        private void btnexcluir_Click(object sender, EventArgs e)
        {
            try
            {
                ItemVenda obj = new ItemVenda();

                obj.id = int.Parse(txtcod.Text);

                ItemVendaDAO dao = new ItemVendaDAO();
                dao.excluir(obj);

                MessageBox.Show("Venda Excluída com Sucesso!!");

                tabelaI.DataSource = dao.ListarTodosItemVendas();
            }
            catch (Exception erro)
            {
                MessageBox.Show("ERRO : " + erro);
            }
        }

        private void btnalterar_Click(object sender, EventArgs e)
        {
            try
            {
                ItemVenda obj = new ItemVenda();

              obj.Produto_id = int.Parse(cbproduto.SelectedValue.ToString());
                obj.Venda_id = int.Parse(cbvenda.Text);
                obj.Quantidade = int.Parse(txtqtd.Text);
                obj.Sub_Total = double.Parse(txtsub.Text);

                obj.id = int.Parse(txtcod.Text);

                ItemVendaDAO dao = new ItemVendaDAO();
                dao.alterar(obj);
                MessageBox.Show("Dados Alterados com Sucesso!!");

                tabelaI.DataSource = dao.ListarTodosItemVendas();
            }
            catch (Exception erro)
            {
                MessageBox.Show("ERRO : " + erro);
            }
        }

        private void Caditemvenda_Load(object sender, EventArgs e)
        {
            ItemVendaDAO dao = new ItemVendaDAO();
            tabelaI.DataSource = dao.ListarTodosItemVendas();
            VendasDAO fdao = new VendasDAO();
            cbvenda.DataSource = fdao.ListarTodosVendas();
            cbvenda.DisplayMember = "id";
            cbvenda.ValueMember = "id";

            ProdutoDAO pdao = new ProdutoDAO();
            cbproduto.DataSource = pdao.ListarTodosProdutos();
            cbproduto.DisplayMember = "descricao";
            cbproduto.ValueMember = "id";
        }

        private void tabelaI_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtcod.Text = tabelaI.CurrentRow.Cells[0].Value.ToString();
            cbproduto.Text = tabelaI.CurrentRow.Cells[1].Value.ToString();
            cbvenda.Text = tabelaI.CurrentRow.Cells[2].Value.ToString();
            txtqtd.Text = tabelaI.CurrentRow.Cells[3].Value.ToString();
            txtsub.Text = tabelaI.CurrentRow.Cells[4].Value.ToString();
        }

        private void btnbuscar_Click(object sender, EventArgs e)
        {
            try
            {
                ItemVenda i = new ItemVenda();
                i.Produto_id = int.Parse(cbproduto.Text);
                ItemVendaDAO dao = new ItemVendaDAO();

                if (dao.buscarNome(i).Rows.Count != 0)
                {
                    tabelaI.DataSource = dao.buscarNome(i);
                }
                else
                {
                    MessageBox.Show("Nenhum registro encontrado");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Digite somente letras");
            }
        }

        private void btnatualizar_Click(object sender, EventArgs e)
        {
            try
            {
                string nome = "";
                ItemVendaDAO dao = new ItemVendaDAO();

                if (dao.Atualizar(nome).Rows.Count != 0)
                {

                    tabelaI.DataSource = dao.Atualizar(nome);
                }

                else
                {
                    MessageBox.Show("Nenhum registro encontrado");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Digite somente letras");
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void txtbuscar_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
