﻿using ProjetoVendas.br.com.projeto.dao;
using ProjetoVendas.br.com.projeto.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoVendas.br.com.projeto.views
{
    public partial class CadVendas : Form
    {
        public CadVendas()
        {
            InitializeComponent();
        }

        private void btncad_Click(object sender, EventArgs e)
        {
            try
            {
                Vendas obj = new Vendas();
                DateTime dt = DateTime.Parse(dateTimePicker1.Value.ToShortDateString());

                obj.Data_Venda = DateTime.Parse(dt.ToString("yyyy-MM-dd"));
             
                
                obj.Total_Venda = int.Parse(txttotal.Text);
                obj.Cliente_id = int.Parse(txtcliente.SelectedValue.ToString());
              

                VendasDAO dao = new VendasDAO();
                dao.cadastrar(obj);
                MessageBox.Show("Cadastrado com Sucesso!!");
            }
            catch (Exception erro)
            {
                MessageBox.Show("ERRO : " + erro);
            }
        }

        private void btnexcluir_Click(object sender, EventArgs e)
        {
            try
            {
                Vendas obj = new Vendas();

                obj.id = int.Parse(txtcod.Text);

                VendasDAO dao = new VendasDAO();
                dao.excluir(obj);

                MessageBox.Show("Venda Excluída com Sucesso!!");

                tabelaV.DataSource = dao.ListarTodosVendas();
            }
            catch (Exception erro)
            {
                MessageBox.Show("ERRO : " + erro);
            }
        }

        private void btnalterar_Click(object sender, EventArgs e)
        {
            try
            {
                Vendas obj = new Vendas();

                DateTime dt = DateTime.Parse(dateTimePicker1.Value.ToShortDateString());

                obj.Data_Venda = DateTime.Parse(dt.ToString("yyyy-MM-dd"));
                obj.Total_Venda = int.Parse(txttotal.Text);
                obj.Cliente_id = int.Parse(txtcliente.Text);

                obj.id = int.Parse(txtcod.Text);

                VendasDAO dao = new VendasDAO();
                dao.alterar(obj);
                MessageBox.Show("Dados Alterados com Sucesso!!");

                tabelaV.DataSource = dao.ListarTodosVendas();
            }
            catch (Exception erro)
            {
                MessageBox.Show("ERRO : " + erro);
            }
        }

        private void tabelaV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtcod.Text = tabelaV.CurrentRow.Cells[0].Value.ToString();
            dateTimePicker1.Text = tabelaV.CurrentRow.Cells[1].Value.ToString();
            txttotal.Text = tabelaV.CurrentRow.Cells[2].Value.ToString();
            txtcliente.Text = tabelaV.CurrentRow.Cells[3].Value.ToString();
        }

        private void CadVendas_Load(object sender, EventArgs e)
        {
            VendasDAO dao = new VendasDAO();
            tabelaV.DataSource = dao.ListarTodosVendas();
            ClienteDAO fdao = new ClienteDAO();
            txtcliente.DataSource = fdao.ListarTodosClientes();
            txtcliente.DisplayMember = "nome";
            txtcliente.ValueMember = "id";
        }

        private void btnbuscar_Click(object sender, EventArgs e)
        {
            try
            {
                Vendas p = new Vendas();
                p.Cliente_id = int.Parse(txtcod.Text);
                VendasDAO dao = new VendasDAO();

                if (dao.buscarNome(p).Rows.Count != 0)
                {
                    tabelaV.DataSource = dao.buscarNome(p);
                }
                else
                {
                    MessageBox.Show("Nenhum registro encontrado");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Digite somente letras");
            }
        }

        private void btnatualizar_Click(object sender, EventArgs e)
        {
            try
            {
                string nome = "";
                VendasDAO dao = new VendasDAO();

                if (dao.Atualizar(nome).Rows.Count != 0)
                {

                    tabelaV.DataSource = dao.Atualizar(nome);
                }

                else
                {
                    MessageBox.Show("Nenhum registro encontrado");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Digite somente letras");
            }
        }

        private void txtcliente_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            
            
         
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
