﻿using ProjetoVendas.br.com.projeto.dao;
using ProjetoVendas.br.com.projeto.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoVendas.br.com.projeto.views
{
    public partial class CadProduto : Form
    {
        public CadProduto()
        {
            InitializeComponent();
        }

        private void btncad_Click(object sender, EventArgs e)
        {
            try
            {
                Produto obj = new Produto();

                obj.Descricao = txtdesc.Text;
                obj.Preco = double.Parse(txtpreco.Text);
                obj.Quantidade = int.Parse(txtqtd.Text);
                obj.for_id = int.Parse(cbforn.SelectedValue.ToString());

                ProdutoDAO dao = new ProdutoDAO();
                dao.cadastrar(obj);
                MessageBox.Show("Cadastrado com Sucesso!!");
            }
            catch (Exception erro)
            {
                MessageBox.Show("ERRO : " + erro);
            }
        }

        private void btnalterar_Click(object sender, EventArgs e)
        {
            try
            {
                Produto obj = new Produto();

                obj.Descricao = txtdesc.Text;
                obj.Preco = int.Parse(txtpreco.Text);
                obj.Quantidade = int.Parse(txtqtd.Text);
                obj.for_id = int.Parse(cbforn.SelectedValue.ToString());

                obj.id = int.Parse(txtcod.Text);

                ProdutoDAO dao = new ProdutoDAO();
                dao.alterar(obj);
                MessageBox.Show("Dados Alterados com Sucesso!!");

                tabelaP.DataSource = dao.ListarTodosProdutos();
            }
            catch (Exception erro)
            {
                MessageBox.Show("ERRO : " + erro);
            }
        }

        private void btnexcluir_Click(object sender, EventArgs e)
        {
            try
            {
                Produto obj = new Produto();

                obj.id = int.Parse(txtcod.Text);

                ProdutoDAO dao = new ProdutoDAO();
                dao.excluir(obj);

                MessageBox.Show("Produto Excluído com Sucesso!!");

                tabelaP.DataSource = dao.ListarTodosProdutos();
            }
            catch (Exception erro)
            {
                MessageBox.Show("ERRO : " + erro);
            }
        }

        private void tabelaP_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtcod.Text = tabelaP.CurrentRow.Cells[0].Value.ToString();
            txtdesc.Text = tabelaP.CurrentRow.Cells[1].Value.ToString();
            txtpreco.Text = tabelaP.CurrentRow.Cells[2].Value.ToString();
            txtqtd.Text = tabelaP.CurrentRow.Cells[3].Value.ToString();
            cbforn.Text = tabelaP.CurrentRow.Cells[4].Value.ToString();
        }

        private void CadProduto_Load(object sender, EventArgs e)
        {
            ProdutoDAO dao = new ProdutoDAO();
            FornecedorDAO fdao = new FornecedorDAO();
            cbforn.DataSource = fdao.ListarTodosFornecedores();
            cbforn.DisplayMember = "nome";
            cbforn.ValueMember = "id";


            tabelaP.DataSource = dao.ListarTodosProdutos();
        }

        private void btnatualizar_Click(object sender, EventArgs e)
        {
            try
            {
                string nome = "";
                ProdutoDAO dao = new ProdutoDAO();

                if (dao.Atualizar(nome).Rows.Count != 0)
                {

                    tabelaP.DataSource = dao.Atualizar(nome);
                }

                else
                {
                    MessageBox.Show("Nenhum registro encontrado");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Digite somente letras");
            }
        }

        private void btnbuscar_Click(object sender, EventArgs e)
        {
              try
            {
                Produto p = new Produto();
                p.Descricao = txtbuscar.Text;
                ProdutoDAO dao = new ProdutoDAO();

                if (dao.buscarNome(p).Rows.Count != 0)
                {
                    tabelaP.DataSource = dao.buscarNome(p);
                }
                else
                {
                    MessageBox.Show("Nenhum registro encontrado");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Digite somente letras");
            }
        }
        }
    }

