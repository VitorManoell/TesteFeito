﻿using ProjetoVendas.br.com.projeto.dao;
using ProjetoVendas.br.com.projeto.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoVendas
{
    public partial class CadCliente : Form
    {
        public CadCliente()
        {
            InitializeComponent();
        }

        private void btncad_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente obj = new Cliente();
              

                obj.Nome = txtnome.Text;
                obj.Telefone = txttel.Text;
                obj.Email = txtemail.Text;
        

                ClienteDAO dao = new ClienteDAO();
                dao.cadastrar(obj);
                MessageBox.Show("Cadastrado com Sucesso!!");
            }
            catch (Exception erro)
            {
                MessageBox.Show("ERRO : " + erro);
            }
        }

        private void btnalterar_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente obj = new Cliente();

                obj.Nome = txtnome.Text;              
                obj.Email = txtemail.Text;
                obj.Telefone = txttel.Text;
                

                obj.Id = int.Parse(txtcod.Text);


                ClienteDAO dao = new ClienteDAO();
                dao.alterar(obj);
                MessageBox.Show("Dados Alterados com Sucesso!!");

                tabelaCliente.DataSource = dao.ListarTodosClientes();
            }
            catch (Exception erro)
            {
                MessageBox.Show("ERRO : " + erro);
            }
        }

        private void btnexcluir_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente obj = new Cliente();

                obj.Id = int.Parse(txtcod.Text);

                ClienteDAO dao = new ClienteDAO();
                dao.excluir(obj);

                MessageBox.Show("Cliente Excluído com Sucesso!!");

                tabelaCliente.DataSource = dao.ListarTodosClientes();
            }
            catch (Exception erro){
                MessageBox.Show("ERRO : "+ erro);
            }

            }

        private void CadCliente_Load(object sender, EventArgs e)
        {
            ClienteDAO dao = new ClienteDAO();
            tabelaCliente.DataSource = dao.ListarTodosClientes ();
        }

        private void tabelaCliente_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtcod.Text = tabelaCliente.CurrentRow.Cells[0].Value.ToString();
            txtnome.Text = tabelaCliente.CurrentRow.Cells[1].Value.ToString();
            txttel.Text = tabelaCliente.CurrentRow.Cells[2].Value.ToString();
            txtemail.Text = tabelaCliente.CurrentRow.Cells[3].Value.ToString();
  

        }

        private void tabelaCliente_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtcod.Text = tabelaCliente.CurrentRow.Cells[0].Value.ToString();
            txtnome.Text = tabelaCliente.CurrentRow.Cells[1].Value.ToString();
            txttel.Text = tabelaCliente.CurrentRow.Cells[2].Value.ToString();
            txtemail.Text = tabelaCliente.CurrentRow.Cells[3].Value.ToString();
          
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtcod_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtnome_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtemail_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txttel_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void cbsexo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnbuscar_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente c = new Cliente();
                c.Nome = txtbuscar.Text;
                ClienteDAO dao = new ClienteDAO();

                if (dao.buscarNome(c).Rows.Count != 0)
                {
                    tabelaCliente.DataSource = dao.buscarNome(c);
                }
                else
                {
                    MessageBox.Show("Nenhum registro encontrado");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Digite somente letras");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string nome = "";
                ClienteDAO dao = new ClienteDAO();

                if (dao.Atualizar(nome).Rows.Count != 0)
                {

                    tabelaCliente.DataSource = dao.Atualizar(nome);
                }

                else
                {
                    MessageBox.Show("Nenhum registro encontrado");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Digite somente letras");
            }
        }
    }
    }

