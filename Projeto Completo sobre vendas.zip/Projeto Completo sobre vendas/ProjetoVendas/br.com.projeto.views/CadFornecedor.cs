﻿using ProjetoVendas.br.com.projeto.dao;
using ProjetoVendas.br.com.projeto.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoVendas.br.com.projeto.views
{
    public partial class CadFornecedor : Form
    {
        public CadFornecedor()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcod_TextChanged(object sender, EventArgs e)
        {

        }

        private void btncad_Click(object sender, EventArgs e)
        {
            try
            {
                Fornecedor obj = new Fornecedor();

                obj.Nome = txtnome.Text;
                obj.CNPJ = int.Parse(textcn.Text);
                obj.Endereco = txtend.Text;
                obj.Bairro = textbairro.Text;
                obj.Cidade = textcidade.Text;
                obj.Numero = int.Parse(textnum.Text); 
                obj.Telefone = texttel.Text;
                obj.Email = textemail.Text;

                FornecedorDAO dao = new FornecedorDAO();
                dao.cadastrar(obj);
                MessageBox.Show("Cadastrado com Sucesso!!");
            }
            catch (Exception erro)
            {
                MessageBox.Show("ERRO : " + erro);
            }
        }

        private void btnexcluir_Click(object sender, EventArgs e)
        {
            try
            {
                Fornecedor obj = new Fornecedor();

                obj.id = int.Parse(txtcod.Text);

                FornecedorDAO dao = new FornecedorDAO();
                dao.excluir(obj);

                MessageBox.Show("Fornecedor Excluído com Sucesso!!");

                tabelaF.DataSource = dao.ListarTodosFornecedores();
            }
            catch (Exception erro)
            {
                MessageBox.Show("ERRO : " + erro);
            }

        }

        private void btnalterar_Click(object sender, EventArgs e)
        {
            try
            {
                Fornecedor obj = new Fornecedor();

                obj.Nome = txtnome.Text;
                obj.CNPJ = int.Parse(textcn.Text);
                obj.Endereco = txtend.Text;
                obj.Bairro = textbairro.Text;
                obj.Cidade = textcidade.Text;
                obj.Numero = int.Parse(textnum.Text);
                obj.Telefone = texttel.Text;
                obj.Email = textemail.Text;


                obj.id = int.Parse(txtcod.Text);

                FornecedorDAO dao = new FornecedorDAO();
                dao.alterar(obj);
                MessageBox.Show("Dados Alterados com Sucesso!!");

                tabelaF.DataSource = dao.ListarTodosFornecedores();
            }
            catch (Exception erro)
            {
                MessageBox.Show("ERRO : " + erro);
            }
        }


        private void tabelaF_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            txtcod.Text = tabelaF.CurrentRow.Cells[0].Value.ToString();
            txtnome.Text = tabelaF.CurrentRow.Cells[1].Value.ToString();
            textcn.Text = tabelaF.CurrentRow.Cells[2].Value.ToString();
            txtend.Text = tabelaF.CurrentRow.Cells[3].Value.ToString();
            textbairro.Text = tabelaF.CurrentRow.Cells[4].Value.ToString();
            textcidade.Text = tabelaF.CurrentRow.Cells[5].Value.ToString();
            textnum.Text = tabelaF.CurrentRow.Cells[6].Value.ToString();
            texttel.Text = tabelaF.CurrentRow.Cells[7].Value.ToString();
            textemail.Text = tabelaF.CurrentRow.Cells[8].Value.ToString();
        }

        private void CadFornecedor_Load(object sender, EventArgs e)
        {
            FornecedorDAO dao = new FornecedorDAO();
            tabelaF.DataSource = dao.ListarTodosFornecedores();
        }

        private void btnbuscar_Click(object sender, EventArgs e)
        {
            try
            {
                Fornecedor f = new Fornecedor();
                f.Nome = txtbuscar.Text;
                FornecedorDAO dao = new FornecedorDAO();

                if (dao.BuscarPorNome(f).Rows.Count != 0)
                {
                    tabelaF.DataSource = dao.BuscarPorNome(f);
                }
                else
                {
                    MessageBox.Show("Nenhum registro encontrado");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Digite somente letras");
            }
        }

        private void txtbuscar_TextChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string nome = "";
                FornecedorDAO dao = new FornecedorDAO();

                if (dao.Atualizar(nome).Rows.Count != 0)
                {

                    tabelaF.DataSource = dao.Atualizar(nome);
                }

                else
                {
                    MessageBox.Show("Nenhum registro encontrado");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Digite somente letras");
            }
        }
    }
}
